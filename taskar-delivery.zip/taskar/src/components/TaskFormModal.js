"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { useTasks } from "@/context/TaskContext";

const EMPTY = {
  ticketId: "",
  parentId: "",
  type: "Task",
  name: "",
  status: "",
  priority: "Normal",
  assignee: "",
  startDate: "",
  targetDate: "",
  progress: 0,
  description: "",
  githubBranch: "",
  jiraLink: "",
};

export default function TaskFormModal({ open, onClose, task = null }) {
  const { config, addTask, updateTask, tasks } = useTasks();
  const [form, setForm] = useState(EMPTY);
  const isEdit = Boolean(task);

  // Reset the form whenever the modal opens or the target task changes.
  useEffect(() => {
    if (open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setForm(
        task
          ? {
              ticketId: task.ticketId === "N/A" ? "" : task.ticketId,
              parentId: task.parentId || "",
              type: task.type,
              name: task.name,
              status: task.status,
              priority: task.priority,
              assignee: task.assignee,
              startDate: task.startDate || "",
              targetDate: task.targetDate || "",
              progress: task.progress || 0,
              description: task.description || "",
              githubBranch: task.githubBranch === "N/A" ? "" : task.githubBranch,
              jiraLink: task.jiraLink || "",
            }
          : { ...EMPTY, status: config.statuses[0] || "Not Started" }
      );
    }
  }, [open, task, config.statuses]);

  if (!open) return null;

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim()) return;
    const payload = {
      ...form,
      ticketId: form.ticketId.trim() || "N/A",
      parentId: form.parentId || null,
      githubBranch: form.githubBranch.trim() || "N/A",
      jiraLink: form.jiraLink.trim() || null,
    };
    if (isEdit) {
      updateTask(task.id, payload);
    } else {
      addTask(payload);
    }
    onClose();
  }

  const parentOptions = tasks.filter(
    (t) => t.id !== task?.id && t.type !== "Subtask"
  );

  return (
    <div className="fixed inset-0 z-50 flex items-stretch justify-center bg-slate-900/40 sm:items-center sm:p-4">
      <div className="flex h-full w-full flex-col overflow-y-auto bg-white shadow-xl sm:h-auto sm:max-h-[90vh] sm:max-w-xl sm:rounded-xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-5 py-4">
          <h2 className="text-sm font-semibold text-slate-900">
            {isEdit ? `Edit ${task.ticketId}` : "New task"}
          </h2>
          <button
            onClick={onClose}
            className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 px-5 py-4">
          <div>
            <label className="mb-1 block text-xs font-medium text-slate-500">
              Task name *
            </label>
            <input
              autoFocus
              required
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              placeholder="e.g. Bank Reconciliation"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Ticket ID
              </label>
              <input
                value={form.ticketId}
                onChange={(e) => set("ticketId", e.target.value)}
                placeholder="N/A"
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Type
              </label>
              <select
                value={form.type}
                onChange={(e) => set("type", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              >
                {config.types.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-500">
              Parent task (for subtasks)
            </label>
            <select
              value={form.parentId}
              onChange={(e) => set("parentId", e.target.value)}
              className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
            >
              <option value="">None</option>
              {parentOptions.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.ticketId} — {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => set("status", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              >
                {config.statuses.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Priority
              </label>
              <select
                value={form.priority}
                onChange={(e) => set("priority", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              >
                {config.priorities.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Assignee
              </label>
              <select
                value={form.assignee}
                onChange={(e) => set("assignee", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              >
                <option value="">Unassigned</option>
                {config.assignees.map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Start date
              </label>
              <input
                type="date"
                value={form.startDate}
                onChange={(e) => set("startDate", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Target date
              </label>
              <input
                type="date"
                value={form.targetDate}
                onChange={(e) => set("targetDate", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Progress %
              </label>
              <input
                type="number"
                min={0}
                max={100}
                value={form.progress}
                onChange={(e) => set("progress", e.target.value)}
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-medium text-slate-500">
              Description
            </label>
            <textarea
              rows={3}
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                GitHub branch
              </label>
              <input
                value={form.githubBranch}
                onChange={(e) => set("githubBranch", e.target.value)}
                placeholder="N/A"
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Jira link
              </label>
              <input
                value={form.jiraLink}
                onChange={(e) => set("jiraLink", e.target.value)}
                placeholder="https://your-domain.atlassian.net/browse/..."
                className="w-full rounded-md border border-slate-200 px-3 py-2 text-sm focus:border-slate-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="rounded-md px-3 py-2 text-sm font-medium text-slate-500 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
            >
              {isEdit ? "Save changes" : "Create task"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
