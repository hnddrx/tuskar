"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  Plus,
  Search,
  X,
  Trash2,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { useTasks } from "@/context/TaskContext";
import { StatusBadge, PriorityBadge, TypeBadge, SyncBadge } from "@/components/Badge";
import { ProgressBar } from "@/components/ProgressBar";
import TaskFormModal from "@/components/TaskFormModal";
import PageHeader from "@/components/PageHeader";
import TaskFiltersPanel, {
  DEFAULT_FILTERS,
  countActiveFilters,
} from "@/components/TaskFiltersPanel";

const PAGE_SIZES = [10, 25, 50, 100];

const COLUMNS = [
  { key: "ticketId", label: "Ticket" },
  { key: "name", label: "Task" },
  { key: "type", label: "Type" },
  { key: "status", label: "Status" },
  { key: "priority", label: "Priority" },
  { key: "assignee", label: "Assignee" },
  { key: "targetDate", label: "Target date" },
  { key: "progress", label: "Progress" },
  { key: "commentCount", label: "Comments" },
  { key: "syncSource", label: "Source" },
];

function normalize(v) {
  return (v ?? "").toString().toLowerCase();
}

function compareValues(a, b, key) {
  if (key === "progress" || key === "commentCount") {
    return (a[key] || 0) - (b[key] || 0);
  }
  if (key === "targetDate") {
    return (a.targetDate || "9999") < (b.targetDate || "9999") ? -1 : 1;
  }
  return normalize(a[key]) < normalize(b[key]) ? -1 : 1;
}

export default function TasksPage() {
  const { tasks, comments, config, deleteTask } = useTasks();
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [sort, setSort] = useState({ key: "lastUpdate", dir: "desc" });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const commentsByTask = useMemo(() => {
    const map = new Map();
    for (const c of comments) {
      if (!map.has(c.ticketId)) map.set(c.ticketId, []);
      map.get(c.ticketId).push(c.text);
    }
    return map;
  }, [comments]);

  const tasksById = useMemo(() => new Map(tasks.map((t) => [t.id, t])), [tasks]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    return tasks.filter((t) => {
      if (filters.statuses.length && !filters.statuses.includes(t.status)) return false;
      if (filters.priorities.length && !filters.priorities.includes(t.priority))
        return false;
      if (filters.assignees.length && !filters.assignees.includes(t.assignee))
        return false;
      if (filters.source === "jira" && t.syncSource !== "Jira") return false;
      if (filters.source === "manual" && t.syncSource === "Jira") return false;

      if (filters.dueFrom && (!t.targetDate || t.targetDate < filters.dueFrom))
        return false;
      if (filters.dueTo && (!t.targetDate || t.targetDate > filters.dueTo))
        return false;

      const createdDate = t.createdAt?.slice(0, 10);
      if (filters.createdFrom && (!createdDate || createdDate < filters.createdFrom))
        return false;
      if (filters.createdTo && (!createdDate || createdDate > filters.createdTo))
        return false;

      if (q) {
        const haystack = [
          t.ticketId,
          t.name,
          t.description,
          t.assignee,
          t.status,
          t.priority,
          ...(commentsByTask.get(t.id) || []),
        ]
          .join(" ")
          .toLowerCase();
        if (!haystack.includes(q)) return false;
      }

      return true;
    });
  }, [tasks, query, filters, commentsByTask]);

  const sorted = useMemo(() => {
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => dir * compareValues(a, b, sort.key));
  }, [filtered, sort]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pageItems = sorted.slice((safePage - 1) * pageSize, safePage * pageSize);

  function updateQuery(v) {
    setQuery(v);
    setPage(1);
  }

  function updateFilters(v) {
    setFilters(v);
    setPage(1);
  }

  function toggleSort(key) {
    setSort((s) =>
      s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }
    );
    setPage(1);
  }

  function openEdit(task) {
    setEditing(task);
    setModalOpen(true);
  }

  function openNew() {
    setEditing(null);
    setModalOpen(true);
  }

  const hasActiveQuery = query.trim().length > 0;
  const activeFilterCount = countActiveFilters(filters);

  return (
    <div className="flex-1">
      <PageHeader
        title="Task Table"
        subtitle={`${sorted.length} of ${tasks.length} task${tasks.length === 1 ? "" : "s"}`}
        actions={
          <button
            onClick={openNew}
            className="flex items-center gap-1.5 rounded-md bg-slate-900 px-3.5 py-2 text-sm font-medium text-white hover:bg-slate-800"
          >
            <Plus size={16} /> New task
          </button>
        }
        mobileFab={filtersOpen ? undefined : { onClick: openNew, label: "New task" }}
      >
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px] flex-1 sm:flex-none sm:w-72">
            <Search
              size={15}
              className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={query}
              onChange={(e) => updateQuery(e.target.value)}
              placeholder="Search tasks, comments, people…"
              className="w-full rounded-md border border-slate-200 bg-white py-1.5 pl-8 pr-7 text-sm focus:border-slate-400 focus:outline-none"
            />
            {hasActiveQuery && (
              <button
                onClick={() => updateQuery("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X size={14} />
              </button>
            )}
          </div>

          <TaskFiltersPanel
            open={filtersOpen}
            onOpenChange={setFiltersOpen}
            config={config}
            filters={filters}
            onChange={updateFilters}
          />

          {(activeFilterCount > 0 || hasActiveQuery) && (
            <button
              onClick={() => {
                updateQuery("");
                updateFilters(DEFAULT_FILTERS);
              }}
              className="text-xs font-medium text-slate-500 hover:text-slate-800"
            >
              Reset all
            </button>
          )}

          <select
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPage(1);
            }}
            className="ml-auto rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-600 focus:border-slate-400 focus:outline-none"
          >
            {PAGE_SIZES.map((n) => (
              <option key={n} value={n}>
                {n} / page
              </option>
            ))}
          </select>
        </div>
      </PageHeader>

      <div className="px-4 py-6 sm:px-8">
        {/* Desktop / tablet table */}
        <div className="hidden overflow-x-auto rounded-xl border border-slate-200 bg-white md:block">
          <table className="w-full min-w-[1100px] text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-left text-xs font-medium uppercase tracking-wide text-slate-400">
                {COLUMNS.map((col) => (
                  <th key={col.key} className="px-4 py-3">
                    <button
                      onClick={() => toggleSort(col.key)}
                      className="flex items-center gap-1 hover:text-slate-700"
                    >
                      {col.label}
                      {sort.key === col.key ? (
                        sort.dir === "asc" ? (
                          <ArrowUp size={12} />
                        ) : (
                          <ArrowDown size={12} />
                        )
                      ) : (
                        <ArrowUpDown size={11} className="opacity-30" />
                      )}
                    </button>
                  </th>
                ))}
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {pageItems.map((t) => {
                const parent = t.parentId ? tasksById.get(t.parentId) : null;
                return (
                  <tr
                    key={t.id}
                    className="group border-b border-slate-50 last:border-0 hover:bg-slate-50"
                  >
                    <td className="whitespace-nowrap px-4 py-2.5 font-mono text-xs text-slate-500">
                      {t.ticketId}
                    </td>
                    <td className="max-w-xs px-4 py-2.5">
                      <Link
                        href={`/tasks/${t.id}`}
                        className="block truncate font-medium text-slate-800 hover:underline"
                        title={t.name}
                      >
                        {t.name}
                      </Link>
                      {parent && (
                        <span className="text-xs text-slate-400">
                          ↳ subtask of {parent.ticketId}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5">
                      <TypeBadge type={t.type} />
                    </td>
                    <td className="px-4 py-2.5">
                      <button onClick={() => openEdit(t)}>
                        <StatusBadge status={t.status} />
                      </button>
                    </td>
                    <td className="px-4 py-2.5">
                      <PriorityBadge priority={t.priority} />
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-slate-600">
                      {t.assignee}
                    </td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-slate-500">
                      {t.targetDate || "—"}
                    </td>
                    <td className="px-4 py-2.5">
                      <ProgressBar value={t.progress} className="w-28" />
                    </td>
                    <td className="px-4 py-2.5 text-center text-slate-500">
                      {t.commentCount || 0}
                    </td>
                    <td className="px-4 py-2.5">
                      <SyncBadge source={t.syncSource} />
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100">
                        <button
                          onClick={() => openEdit(t)}
                          className="rounded px-2 py-1 text-xs font-medium text-slate-500 hover:bg-slate-100"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete "${t.name}"?`)) deleteTask(t.id);
                          }}
                          className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {pageItems.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-4 py-10 text-center text-sm text-slate-400">
                    No tasks match your search and filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile card list */}
        <div className="space-y-2 md:hidden">
          {pageItems.map((t) => {
            const parent = t.parentId ? tasksById.get(t.parentId) : null;
            return (
              <Link
                key={t.id}
                href={`/tasks/${t.id}`}
                className="block rounded-xl border border-slate-200 bg-white p-3.5"
              >
                <div className="mb-1.5 flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] text-slate-400">
                    {t.ticketId}
                  </span>
                  <SyncBadge source={t.syncSource} />
                </div>
                <p className="mb-1 text-sm font-medium text-slate-800">{t.name}</p>
                {parent && (
                  <p className="mb-1.5 text-xs text-slate-400">
                    ↳ subtask of {parent.ticketId}
                  </p>
                )}
                <div className="mb-2 flex flex-wrap items-center gap-1.5">
                  <TypeBadge type={t.type} />
                  <StatusBadge status={t.status} />
                  <PriorityBadge priority={t.priority} />
                </div>
                <ProgressBar value={t.progress} className="mb-2" />
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{t.assignee}</span>
                  <span>{t.targetDate || "No target date"}</span>
                </div>
              </Link>
            );
          })}
          {pageItems.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white px-4 py-10 text-center text-sm text-slate-400">
              No tasks match your search and filters.
            </div>
          )}
        </div>

        {/* Pagination */}
        {sorted.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-slate-500">
            <p>
              Showing {(safePage - 1) * pageSize + 1}–
              {Math.min(safePage * pageSize, sorted.length)} of {sorted.length}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={safePage <= 1}
                className="rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium disabled:opacity-40"
              >
                Previous
              </button>
              <span className="text-xs">
                Page {safePage} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={safePage >= totalPages}
                className="rounded-md border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium disabled:opacity-40"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      <TaskFormModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        task={editing}
      />
    </div>
  );
}
