"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, Pencil, FileDown, ExternalLink, GitBranch } from "lucide-react";
import { useTasks } from "@/context/TaskContext";
import { StatusBadge, PriorityBadge, TypeBadge, SyncBadge } from "@/components/Badge";
import { ProgressBar } from "@/components/ProgressBar";
import TaskFormModal from "@/components/TaskFormModal";
import CommentThread from "@/components/CommentThread";
import PageHeader from "@/components/PageHeader";
import { generateTaskDoc, downloadMarkdown } from "@/lib/docGenerator";

export default function TaskDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { tasks, comments } = useTasks();
  const [editOpen, setEditOpen] = useState(false);

  const task = tasks.find((t) => t.id === id);

  if (!task) {
    return (
      <div className="flex-1 p-8">
        <p className="text-sm text-slate-500">Task not found.</p>
        <Link href="/tasks" className="text-sm text-slate-900 underline">
          Back to task table
        </Link>
      </div>
    );
  }

  const subtasks = tasks.filter((t) => t.parentId === task.id);
  const parent = task.parentId ? tasks.find((t) => t.id === task.parentId) : null;

  function exportDoc() {
    const doc = generateTaskDoc(task, comments, tasks);
    downloadMarkdown(`${task.ticketId.replace(/[^a-z0-9-]/gi, "_")}.md`, doc);
  }

  return (
    <div className="flex-1">
      <PageHeader
        title={task.name}
        actions={
          <>
            <button
              onClick={exportDoc}
              className="flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
            >
              <FileDown size={14} /> Export doc
            </button>
            <button
              onClick={() => setEditOpen(true)}
              className="flex items-center gap-1.5 rounded-md bg-slate-900 px-3 py-2 text-sm font-medium text-white hover:bg-slate-800"
            >
              <Pencil size={14} /> Edit
            </button>
          </>
        }
      >
        <button
          onClick={() => router.back()}
          className="mb-2 mt-1 flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800"
        >
          <ArrowLeft size={13} /> Back
        </button>
        {parent && (
          <Link
            href={`/tasks/${parent.id}`}
            className="mb-1 inline-block text-xs text-slate-400 hover:underline"
          >
            {parent.ticketId} / {parent.name}
          </Link>
        )}
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-xs text-slate-400">{task.ticketId}</span>
          <TypeBadge type={task.type} />
          <StatusBadge status={task.status} />
          <PriorityBadge priority={task.priority} />
          <SyncBadge source={task.syncSource} />
        </div>
      </PageHeader>

      <div className="px-4 py-6 sm:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <section className="rounded-xl border border-slate-200 bg-white p-5">
              <h2 className="mb-2 text-sm font-semibold text-slate-800">
                Description
              </h2>
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-600">
                {task.description || "No description provided."}
              </p>
            </section>

            <section className="rounded-xl border border-slate-200 bg-white p-5">
              <h2 className="mb-3 text-sm font-semibold text-slate-800">
                Comments &amp; update history
              </h2>
              <CommentThread taskId={task.id} />
            </section>

            {subtasks.length > 0 && (
              <section className="rounded-xl border border-slate-200 bg-white p-5">
                <h2 className="mb-3 text-sm font-semibold text-slate-800">
                  Subtasks ({subtasks.length})
                </h2>
                <div className="space-y-2">
                  {subtasks.map((s) => (
                    <Link
                      key={s.id}
                      href={`/tasks/${s.id}`}
                      className="flex items-center justify-between gap-2 rounded-lg border border-slate-100 px-3 py-2 hover:bg-slate-50"
                    >
                      <div className="flex min-w-0 items-center gap-2">
                        <span className="shrink-0 font-mono text-xs text-slate-400">
                          {s.ticketId}
                        </span>
                        <span className="truncate text-sm text-slate-700">
                          {s.name}
                        </span>
                      </div>
                      <StatusBadge status={s.status} />
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>

          <div className="space-y-4">
            <section className="rounded-xl border border-slate-200 bg-white p-5">
              <h2 className="mb-3 text-sm font-semibold text-slate-800">Details</h2>
              <dl className="space-y-3 text-sm">
                <Field label="Assignee" value={task.assignee} />
                <Field label="Start date" value={task.startDate || "—"} />
                <Field label="Target date" value={task.targetDate || "—"} />
                <div>
                  <dt className="text-xs text-slate-400">Progress</dt>
                  <dd className="mt-1">
                    <ProgressBar value={task.progress} />
                  </dd>
                </div>
                <Field label="Last update" value={task.lastUpdate || "—"} />
                <div>
                  <dt className="text-xs text-slate-400">GitHub branch</dt>
                  <dd className="mt-1 flex items-center gap-1.5 text-sm text-slate-700">
                    <GitBranch size={13} className="shrink-0 text-slate-400" />
                    <span className="break-all font-mono text-xs">
                      {task.githubBranch || "N/A"}
                    </span>
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-slate-400">Jira</dt>
                  <dd className="mt-1 text-sm">
                    {task.jiraLink ? (
                      <a
                        href={task.jiraLink}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 text-blue-600 hover:underline"
                      >
                        Open in Jira <ExternalLink size={12} />
                      </a>
                    ) : (
                      <span className="text-slate-400">Not linked</span>
                    )}
                  </dd>
                </div>
              </dl>
            </section>
          </div>
        </div>
      </div>

      <TaskFormModal open={editOpen} onClose={() => setEditOpen(false)} task={task} />
    </div>
  );
}

function Field({ label, value }) {
  return (
    <div>
      <dt className="text-xs text-slate-400">{label}</dt>
      <dd className="mt-0.5 text-sm text-slate-700">{value}</dd>
    </div>
  );
}
